#include<vector>
#include<iostream>
using namespace std;
vector<vector<int>> create_random_LDPC_1(int, int, int, int);
vector<vector<int>> create_random_LDPC_1_redundant(int m, int n, int c, int d);
vector<vector<int>> create_random_LDPC_2(int m, int n, int c, int d);
int myrandom (int i);

